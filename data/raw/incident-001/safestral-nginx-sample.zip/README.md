Safestral example from mindweave/web-server-logs on Hugging Face.
Dataset: https://huggingface.co/datasets/mindweave/web-server-logs
License: https://creativecommons.org/licenses/by-nc/4.0/
This archive contains the public subset in Mistraton work/ and its CSV metric export.
